"""
Browsing Context Analyzer for Agent Command Center
Maps user browsing context to Gen Digital product recommendations.
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
from datetime import datetime, timezone


GEN_PRODUCTS = {
    "norton_360": {"name": "Norton 360", "category": "security", "description": "All-in-one device security, VPN, and dark web monitoring", "icon": "ud83dudee1ufe0f", "url": "https://us.norton.com/products/norton-360"},
    "norton_vpn": {"name": "Norton Secure VPN", "category": "privacy", "description": "Bank-grade encryption for public WiFi and private browsing", "icon": "ud83dudd12", "url": "https://us.norton.com/products/norton-secure-vpn"},
    "norton_password_mgr": {"name": "Norton Password Manager", "category": "security", "description": "Generate, store, and autofill strong passwords securely", "icon": "ud83dudd11", "url": "https://us.norton.com/feature/password-manager"},
    "norton_safe_shopping": {"name": "Norton Safe Shopping", "category": "security", "description": "Alerts for unsafe sites, coupon finder, and price tracking", "icon": "ud83duded2", "url": "https://safeweb.norton.com/"},
    "norton_antivirus": {"name": "Norton AntiVirus Plus", "category": "security", "description": "Real-time threat protection, malware defense, and firewall", "icon": "ud83eudda0", "url": "https://us.norton.com/products/norton-antivirus-plus"},
    "norton_family": {"name": "Norton Family", "category": "family", "description": "Parental controls, screen time, location tracking", "icon": "ud83dudc68u200dud83dudc69u200dud83dudc67u200dud83dudc66", "url": "https://family.norton.com/"},
    "norton_safe_search": {"name": "Norton Safe Search", "category": "security", "description": "Safe search engine that flags risky websites", "icon": "ud83dudd0d", "url": "https://safesearch.norton.com/"},
    "lifelock_standard": {"name": "LifeLock Standard", "category": "identity", "description": "Identity theft protection with SSN and credit alerts", "icon": "ud83cudd94", "url": "https://www.lifelock.com/"},
    "lifelock_advantage": {"name": "LifeLock Advantage", "category": "identity", "description": "Enhanced identity protection with bank & credit card monitoring", "icon": "ud83dudcb3", "url": "https://www.lifelock.com/"},
    "lifelock_ultimate": {"name": "LifeLock Ultimate Plus", "category": "identity", "description": "Comprehensive identity protection with investment monitoring", "icon": "ud83cudfe6", "url": "https://www.lifelock.com/"},
    "moneylion_banking": {"name": "MoneyLion Banking", "category": "financial", "description": "Mobile banking with no hidden fees and early paycheck access", "icon": "ud83cudfe7", "url": "https://www.moneylion.com/"},
    "moneylion_credit_builder": {"name": "MoneyLion Credit Builder Plus", "category": "financial", "description": "Build credit with a Credit Builder loan and tracking tools", "icon": "ud83dudcc8", "url": "https://www.moneylion.com/credit-builder-plus/"},
    "moneylion_instacash": {"name": "MoneyLion Instacash", "category": "financial", "description": "Cash advances up to $500 with no interest", "icon": "ud83dudcb5", "url": "https://www.moneylion.com/instacash/"},
    "moneylion_investing": {"name": "MoneyLion Investing", "category": "financial", "description": "Automated investing with managed portfolios", "icon": "ud83dudcca", "url": "https://www.moneylion.com/investing/"},
    "gbr_content": {"name": "GoBankingRates Guides", "category": "education", "description": "Expert financial content u2014 credit cards, savings, mortgages, taxes", "icon": "ud83dudcda", "url": "https://www.gobankingrates.com/"},
}

BROWSING_SIGNALS = {
    "online_shopping": {
        "url_patterns": [r"amazon\.", r"ebay\.", r"walmart\.", r"target\.", r"etsy\.", r"shopify\.", r"shop\.", r"/cart", r"/checkout"],
        "content_keywords": ["add to cart", "buy now", "checkout", "shipping", "order", "price", "discount", "coupon"],
        "products": ["norton_safe_shopping", "norton_vpn", "norton_password_mgr"], "weight": 0.9,
    },
    "banking": {
        "url_patterns": [r"chase\.", r"bankofamerica\.", r"wellsfargo\.", r"citi\.", r"capitalone\.", r"/banking", r"mint\."],
        "content_keywords": ["account balance", "transfer", "checking", "savings", "bank statement", "direct deposit"],
        "products": ["norton_vpn", "lifelock_advantage", "moneylion_banking", "norton_password_mgr"], "weight": 0.95,
    },
    "credit_research": {
        "url_patterns": [r"creditkarma\.", r"annualcreditreport\.", r"experian\.", r"equifax\.", r"transunion\."],
        "content_keywords": ["credit score", "credit report", "fico", "credit card", "apr", "credit limit"],
        "products": ["moneylion_credit_builder", "lifelock_standard", "gbr_content"], "weight": 0.9,
    },
    "investing": {
        "url_patterns": [r"robinhood\.", r"fidelity\.", r"schwab\.", r"etrade\.", r"vanguard\.", r"coinbase\."],
        "content_keywords": ["stock", "portfolio", "invest", "dividend", "etf", "crypto", "retirement", "401k"],
        "products": ["moneylion_investing", "lifelock_ultimate", "norton_vpn", "gbr_content"], "weight": 0.85,
    },
    "email_webmail": {
        "url_patterns": [r"mail\.google\.", r"outlook\.", r"yahoo\.com/mail"],
        "content_keywords": ["inbox", "compose", "reply", "attachment"],
        "products": ["norton_360", "norton_antivirus", "lifelock_standard"], "weight": 0.7,
    },
    "social_media": {
        "url_patterns": [r"facebook\.", r"instagram\.", r"twitter\.", r"tiktok\.", r"linkedin\.", r"reddit\.", r"x\.com"],
        "content_keywords": ["post", "share", "like", "follow", "comment"],
        "products": ["norton_360", "norton_vpn", "lifelock_standard"], "weight": 0.6,
    },
    "kids_content": {
        "url_patterns": [r"youtube\.com/kids", r"pbskids\.", r"nickjr\.", r"disney\."],
        "content_keywords": ["kids", "children", "parental", "family", "educational game"],
        "products": ["norton_family", "norton_360", "norton_safe_search"], "weight": 0.95,
    },
    "tax_filing": {
        "url_patterns": [r"turbotax\.", r"hrblock\.", r"irs\.gov", r"taxact\."],
        "content_keywords": ["tax return", "w-2", "1099", "deduction", "refund"],
        "products": ["lifelock_ultimate", "norton_vpn", "norton_password_mgr", "gbr_content"], "weight": 0.95,
    },
    "public_wifi": {
        "url_patterns": [], "content_keywords": [],
        "network_signals": ["open_network", "public_wifi", "cafe", "airport", "hotel"],
        "products": ["norton_vpn", "norton_360"], "weight": 1.0,
    },
    "password_management": {
        "url_patterns": [r"/login", r"/signin", r"/register", r"/signup", r"/password"],
        "content_keywords": ["password", "sign in", "log in", "register", "create account", "forgot password"],
        "products": ["norton_password_mgr", "norton_360"], "weight": 0.8,
    },
    "mortgage_home": {
        "url_patterns": [r"zillow\.", r"realtor\.", r"redfin\.", r"bankrate\.", r"nerdwallet\."],
        "content_keywords": ["mortgage", "home loan", "refinance", "down payment", "real estate"],
        "products": ["gbr_content", "moneylion_banking", "lifelock_advantage", "norton_vpn"], "weight": 0.85,
    },
    "small_business": {
        "url_patterns": [r"shopify\.", r"square\.", r"quickbooks\.", r"stripe\."],
        "content_keywords": ["small business", "entrepreneur", "invoice", "payroll"],
        "products": ["norton_360", "lifelock_ultimate", "moneylion_banking", "gbr_content"], "weight": 0.8,
    },
}

LIFE_STAGES = {
    "college_student": {"signals": ["social_media", "password_management", "public_wifi"], "keywords": ["student", "college", "university", "campus", "financial aid", "student loan"], "top_products": ["moneylion_credit_builder", "norton_vpn", "moneylion_instacash", "gbr_content"]},
    "young_professional": {"signals": ["banking", "investing", "credit_research"], "keywords": ["salary", "401k", "apartment", "first job", "career"], "top_products": ["moneylion_banking", "moneylion_investing", "lifelock_standard", "norton_360"]},
    "new_family": {"signals": ["kids_content", "mortgage_home", "banking"], "keywords": ["baby", "family", "daycare", "school", "parenting"], "top_products": ["norton_family", "lifelock_advantage", "gbr_content", "moneylion_banking"]},
    "homeowner": {"signals": ["mortgage_home", "tax_filing", "investing"], "keywords": ["mortgage", "home insurance", "property tax", "renovation"], "top_products": ["lifelock_ultimate", "norton_360", "gbr_content", "moneylion_investing"]},
    "small_business_owner": {"signals": ["small_business", "tax_filing", "banking"], "keywords": ["business", "llc", "payroll", "inventory"], "top_products": ["norton_360", "lifelock_ultimate", "moneylion_banking", "gbr_content"]},
}


@dataclass
class ProductRecommendation:
    product_id: str; name: str; category: str; description: str
    icon: str; url: str; relevance_score: float; reason: str

    def to_dict(self):
        return {"product_id": self.product_id, "name": self.name, "category": self.category,
                "description": self.description, "icon": self.icon, "url": self.url,
                "relevance_score": round(self.relevance_score, 2), "reason": self.reason}


@dataclass
class ContextAnalysis:
    timestamp: str; url: str; detected_signals: List[str]
    life_stage: str; risk_factors: List[str]; recommendations: List[ProductRecommendation]

    def to_dict(self):
        return {"timestamp": self.timestamp, "url": self.url, "detected_signals": self.detected_signals,
                "life_stage": self.life_stage, "risk_factors": self.risk_factors,
                "recommendations": [r.to_dict() for r in self.recommendations]}


@dataclass
class BrowsingContext:
    url: str = ""; page_title: str = ""; page_content: str = ""
    network_type: str = "private"; timestamp: str = ""


class BrowsingContextAnalyzer:
    def __init__(self):
        self.history: List[ContextAnalysis] = []

    def analyze(self, context: BrowsingContext) -> ContextAnalysis:
        detected = self._detect_signals(context)
        life_stage = self._infer_life_stage(context, detected)
        risks = self._detect_risks(context, detected)
        recs = self._generate_recommendations(detected, life_stage, context)
        recs.sort(key=lambda r: r.relevance_score, reverse=True)
        recs = recs[:5]

        analysis = ContextAnalysis(datetime.now(timezone.utc).isoformat(), context.url,
                                   detected, life_stage, risks, recs)
        self.history.append(analysis)
        if len(self.history) > 50: self.history = self.history[-50:]
        return analysis

    def _detect_signals(self, ctx):
        signals = []
        combined = f"{ctx.url} {ctx.page_title} {ctx.page_content}".lower()
        for name, sig in BROWSING_SIGNALS.items():
            score = 0.0
            for p in sig.get("url_patterns", []):
                if re.search(p, ctx.url, re.IGNORECASE):
                    score += 0.6; break
            for kw in sig.get("content_keywords", []):
                if kw.lower() in combined: score += 0.15
            for ns in sig.get("network_signals", []):
                if ns in ctx.network_type.lower(): score += 0.8
            if score >= 0.3: signals.append(name)
        return signals

    def _infer_life_stage(self, ctx, signals):
        combined = f"{ctx.url} {ctx.page_title} {ctx.page_content}".lower()
        scores = {}
        for stage, defn in LIFE_STAGES.items():
            s = len(set(signals) & set(defn["signals"])) * 0.3
            s += sum(0.2 for kw in defn["keywords"] if kw.lower() in combined)
            scores[stage] = s
        if not scores or max(scores.values()) < 0.2: return "general_consumer"
        return max(scores, key=scores.get)

    def _detect_risks(self, ctx, signals):
        risks = []
        if "public_wifi" in signals: risks.append("Public WiFi detected u2014 data may be intercepted")
        if any(s in signals for s in ["banking", "investing", "tax_filing"]): risks.append("Sensitive financial activity u2014 identity protection recommended")
        if "password_management" in signals: risks.append("Credential entry detected u2014 use password manager")
        if "online_shopping" in signals: risks.append("Online transaction u2014 verify site safety before purchase")
        if not ctx.url.startswith("https://"): risks.append("Non-HTTPS connection u2014 data not encrypted")
        if "kids_content" in signals: risks.append("Child-oriented content u2014 parental controls recommended")
        return risks

    def _generate_recommendations(self, signals, life_stage, ctx):
        scores: Dict[str, Tuple[float, str]] = {}
        for sig_name in signals:
            sig = BROWSING_SIGNALS.get(sig_name, {})
            w = sig.get("weight", 0.5)
            for pid in sig.get("products", []):
                reason = f"Relevant to {sig_name.replace('_', ' ')}"
                cur = scores.get(pid, (0.0, ""))
                new = cur[0] + w * 0.5
                scores[pid] = (new, reason if new > cur[0] else cur[1])

        for pid in LIFE_STAGES.get(life_stage, {}).get("top_products", []):
            cur = scores.get(pid, (0.0, ""))
            reason = f"Recommended for {life_stage.replace('_', ' ')}s"
            new = cur[0] + 0.3
            scores[pid] = (new, reason if new > cur[0] else cur[1])

        recs = []
        for pid, (score, reason) in scores.items():
            p = GEN_PRODUCTS.get(pid)
            if p and score > 0.1:
                recs.append(ProductRecommendation(pid, p["name"], p["category"], p["description"],
                                                  p["icon"], p["url"], min(1.0, score), reason))
        return recs

    def get_current_products(self):
        return self.history[-1].to_dict()["recommendations"] if self.history else []

    def get_history(self, limit=10):
        return [h.to_dict() for h in self.history[-limit:]]


analyzer = BrowsingContextAnalyzer()
