"""
Prompt Injection Scanner for Agent Command Center
Detects hidden instructions, jailbreak attempts, and malicious payloads.
"""

import re
import base64
import hashlib
import time
from dataclasses import dataclass, field
from typing import List, Dict
from datetime import datetime, timezone


@dataclass
class ThreatDetail:
    category: str
    pattern_matched: str
    severity: str
    description: str
    snippet: str = ""


@dataclass
class ScanResult:
    content_hash: str
    timestamp: str
    safety_score: int
    risk_level: str
    threats: List[ThreatDetail] = field(default_factory=list)
    recommendation: str = ""
    blocked: bool = False
    scan_time_ms: float = 0.0

    def to_dict(self):
        return {
            "content_hash": self.content_hash,
            "timestamp": self.timestamp,
            "safety_score": self.safety_score,
            "risk_level": self.risk_level,
            "threats": [
                {"category": t.category, "pattern_matched": t.pattern_matched,
                 "severity": t.severity, "description": t.description,
                 "snippet": t.snippet[:100]}
                for t in self.threats
            ],
            "recommendation": self.recommendation,
            "blocked": self.blocked,
            "scan_time_ms": self.scan_time_ms,
        }


INSTRUCTION_OVERRIDE_PATTERNS = [
    (r"ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|guidelines?|prompts?)", "CRITICAL", "Direct instruction override attempt"),
    (r"disregard\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|context)", "CRITICAL", "Instruction disregard attempt"),
    (r"forget\s+(everything|all|what)\s+(you|I)\s+(told|said|know)", "HIGH", "Memory wipe attempt"),
    (r"(new|updated|revised)\s+(instructions?|rules?|guidelines?|system\s+prompt)", "HIGH", "Fake instruction update"),
    (r"(override|bypass|skip|circumvent)\s+(safety|security|filter|restriction|guardrail)", "CRITICAL", "Safety bypass attempt"),
    (r"you\s+are\s+now\s+(a|an|in)\s+", "HIGH", "Identity reassignment"),
    (r"from\s+now\s+on\s+(you|your)\s+(are|will|should|must)", "HIGH", "Behavioral override"),
    (r"(pretend|imagine|act\s+as\s+if)\s+(you|there|this)\s+(are|is|were|has)\s+no\s+(rules?|restrictions?|limits?)", "CRITICAL", "Rule nullification"),
    (r"the\s+(real|actual|true)\s+(instructions?|rules?)\s+(are|is|say)", "HIGH", "Fake authority claim"),
]

ROLE_MANIPULATION_PATTERNS = [
    (r"\bDAN\b.*\bdo\s+anything\s+now\b", "CRITICAL", "DAN jailbreak attempt"),
    (r"(jailbreak|unfiltered|uncensored|unrestricted)\s+(mode|version|model)", "CRITICAL", "Jailbreak mode activation"),
    (r"(developer|debug|admin|root|sudo|maintenance)\s+(mode|access|console|override)", "CRITICAL", "Privilege escalation via role"),
    (r"you\s+are\s+(DAN|STAN|DUDE|AIM|Evil|Dark|Shadow|Omega)", "CRITICAL", "Named jailbreak persona"),
    (r"respond\s+(without|with\s+no)\s+(restrictions?|filters?|limitations?|censorship)", "HIGH", "Filter removal request"),
    (r"(act|behave|respond)\s+(as|like)\s+(a|an)\s+(evil|malicious|unethical|unrestricted)", "CRITICAL", "Malicious persona assignment"),
    (r"(enable|activate|turn\s+on)\s+(god|super|unlimited|unrestricted)\s+mode", "CRITICAL", "God mode activation"),
]

DATA_EXFILTRATION_PATTERNS = [
    (r"(send|post|transmit|upload|forward|email)\s+(to|at|this)\s+(https?://|www\.|[\w.-]+\.(com|net|org|io))", "CRITICAL", "Data exfiltration to external URL"),
    (r"(output|print|display|show|reveal|leak)\s+(the\s+)?(system\s+prompt|instructions?|api\s+key|token|password|secret|credential)", "HIGH", "Credential extraction attempt"),
    (r"(curl|wget|fetch|request)\s+(https?://|www\.)", "HIGH", "External HTTP request injection"),
    (r"(base64|encode|encrypt)\s+(and\s+)?(send|post|output)", "HIGH", "Encoded data exfiltration"),
    (r"(connect|ssh|telnet|nc|netcat)\s+(to\s+)?[\d.]+", "CRITICAL", "Network connection attempt"),
]

PRIVILEGE_ESCALATION_PATTERNS = [
    (r"\b(sudo|su\s+-|chmod\s+777|chown\s+root)\b", "CRITICAL", "System privilege escalation"),
    (r"(disable|turn\s+off|deactivate)\s+(security|firewall|antivirus|monitoring|logging|audit)", "CRITICAL", "Security disable attempt"),
    (r"(access|read|cat|head|tail)\s+(/etc/passwd|/etc/shadow|\.env|\.ssh|id_rsa)", "CRITICAL", "Sensitive file access"),
    (r"(rm\s+-rf|del\s+/|format\s+[a-z]:)", "CRITICAL", "Destructive command injection"),
    (r"(eval|exec|os\.system|subprocess|spawn|popen)\s*\(", "HIGH", "Code execution injection"),
]

HIDDEN_CONTENT_PATTERNS = [
    (r"[\u200b\u200c\u200d\u2060\ufeff]{3,}", "HIGH", "Zero-width character hiding"),
    (r"<!--.*?(ignore|instruction|inject|hack|override).*?-->", "HIGH", "HTML comment injection"),
    (r"(?:color|font-size)\s*:\s*(?:transparent|rgba\(0,\s*0,\s*0,\s*0\)|0px)", "HIGH", "Invisible CSS text"),
]

SOCIAL_ENGINEERING_PATTERNS = [
    (r"(I\s+am\s+|this\s+is\s+)(your\s+)?(creator|developer|admin|owner|operator|boss|manager|CEO)", "HIGH", "False authority claim"),
    (r"(authorized|approved|cleared|permitted)\s+by\s+(the\s+)?(admin|developer|system|management)", "HIGH", "Fake authorization claim"),
    (r"(this\s+is\s+a\s+test|testing\s+your|quality\s+assurance|security\s+audit)", "MEDIUM", "Fake testing pretext"),
]

SEPARATOR_INJECTION_PATTERNS = [
    (r"\[?(SYSTEM|ADMIN|DEVELOPER|ROOT)\]?\s*:", "HIGH", "Fake system message"),
    (r"<\|?(system|im_start|im_end|endoftext)\|?>", "CRITICAL", "Token boundary injection"),
    (r"(BEGIN|START)\s+(SYSTEM|ADMIN|INTERNAL)\s+(MESSAGE|PROMPT|INSTRUCTION)", "CRITICAL", "Fake system message delimiter"),
]

ALL_PATTERN_CATEGORIES = {
    "Instruction Override": INSTRUCTION_OVERRIDE_PATTERNS,
    "Role Manipulation": ROLE_MANIPULATION_PATTERNS,
    "Data Exfiltration": DATA_EXFILTRATION_PATTERNS,
    "Privilege Escalation": PRIVILEGE_ESCALATION_PATTERNS,
    "Hidden Content": HIDDEN_CONTENT_PATTERNS,
    "Social Engineering": SOCIAL_ENGINEERING_PATTERNS,
    "Separator Injection": SEPARATOR_INJECTION_PATTERNS,
}

SEVERITY_SCORES = {"CRITICAL": 35, "HIGH": 20, "MEDIUM": 10, "LOW": 5}


class PromptInjectionScanner:
    def __init__(self):
        self.scan_history: List[ScanResult] = []
        self.stats = {"total_scans": 0, "threats_detected": 0, "content_blocked": 0}

    def scan(self, content: str, source: str = "unknown") -> ScanResult:
        start = time.time()
        threats: List[ThreatDetail] = []
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:12]

        # Check base64
        for b64_str in re.findall(r"[A-Za-z0-9+/]{40,}={0,2}", content):
            try:
                decoded = base64.b64decode(b64_str).decode("utf-8", errors="ignore")
                if any(kw in decoded.lower() for kw in ["ignore", "override", "system", "instruction", "password", "token", "sudo"]):
                    threats.append(ThreatDetail("Hidden Content", "base64_payload", "CRITICAL", "Base64-encoded malicious content", f"Decoded: {decoded[:80]}"))
            except Exception:
                pass

        # Pattern matching
        for category, patterns in ALL_PATTERN_CATEGORIES.items():
            for pattern, severity, description in patterns:
                for match in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                    s, e = max(0, match.start() - 20), min(len(content), match.end() + 20)
                    threats.append(ThreatDetail(category, pattern[:60], severity, description, content[s:e]))

        # Heuristics
        if len(content) > 0:
            ctrl = sum(1 for c in content if ord(c) < 32 and c not in "\n\r\t")
            if ctrl / len(content) > 0.05:
                threats.append(ThreatDetail("Hidden Content", "control_chars", "MEDIUM", "High control character ratio", f"{ctrl} control chars"))

        persona_count = len(re.findall(r"(you are|act as|pretend to be|imagine you're)", content, re.IGNORECASE))
        if persona_count >= 3:
            threats.append(ThreatDetail("Role Manipulation", "multi_persona", "HIGH", f"{persona_count} persona manipulation attempts", ""))

        # Score
        total_penalty = sum(SEVERITY_SCORES.get(t.severity, 5) for t in threats)
        safety_score = max(0, 100 - total_penalty)
        if safety_score >= 90: risk_level = "SAFE"
        elif safety_score >= 70: risk_level = "LOW"
        elif safety_score >= 50: risk_level = "MEDIUM"
        elif safety_score >= 25: risk_level = "HIGH"
        else: risk_level = "CRITICAL"

        blocked = safety_score < 70
        recommendation = self._recommend(risk_level, threats)
        elapsed = (time.time() - start) * 1000

        result = ScanResult(content_hash, datetime.now(timezone.utc).isoformat(), safety_score,
                            risk_level, threats, recommendation, blocked, round(elapsed, 2))

        self.scan_history.append(result)
        if len(self.scan_history) > 100:
            self.scan_history = self.scan_history[-100:]
        self.stats["total_scans"] += 1
        if threats: self.stats["threats_detected"] += len(threats)
        if blocked: self.stats["content_blocked"] += 1
        return result

    def _recommend(self, risk_level, threats):
        if risk_level == "SAFE": return "Content appears safe. No action needed."
        if risk_level == "LOW": return "Minor suspicious patterns. Monitor agent behavior."
        if risk_level == "MEDIUM": return "Moderate risk. Review before allowing agent to process."
        if risk_level == "HIGH": return "High risk content. Block agent access and review manually."
        cats = list(set(t.category for t in threats))
        return f"CRITICAL threat in: {', '.join(cats)}. Content blocked automatically."

    def get_stats(self):
        return {**self.stats, "recent_scans": [s.to_dict() for s in self.scan_history[-10:]]}

    def get_recent_alerts(self, limit=20):
        return [s.to_dict() for s in self.scan_history if s.threats][-limit:]


scanner = PromptInjectionScanner()
