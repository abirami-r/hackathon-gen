#!/bin/bash
# Agent Command Center - Deploy Script
set -e
echo "Deploying Agent Command Center..."

kill $(lsof -t -i:8080) 2>/dev/null || true
sleep 1

DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Starting API server on port 8080..."
cd "$DIR/agent-command-center"
nohup python3 api_server.py > /tmp/acc-api.log 2>&1 &
echo "API PID: $!"

sleep 2
if curl -s http://localhost:8080/api/health > /dev/null 2>&1; then
    echo "API is running!"
else
    echo "API failed to start. Check /tmp/acc-api.log"
    exit 1
fi

echo ""
echo "DEPLOYMENT COMPLETE"
echo "API: http://localhost:8080"
echo "Logs: tail -f /tmp/acc-api.log"
