(function() {
  if (document.getElementById('acc-fab')) return;
  
  var API = 'https://autono-mates-neoclaw.securebrowser.com';

  var fab = document.createElement('div');
  fab.id = 'acc-fab';
  fab.innerHTML = '&#9889;';
  var badge = document.createElement('div');
  badge.id = 'acc-badge';
  badge.textContent = '--';
  fab.appendChild(badge);
  document.body.appendChild(fab);

  var panel = document.createElement('div');
  panel.id = 'acc-panel';
  document.body.appendChild(panel);

  var isOpen = false;
  fab.onclick = function() {
    isOpen = !isOpen;
    panel.classList.toggle('open', isOpen);
    if (isOpen) loadPanel();
  };

  async function loadPanel() {
    panel.innerHTML = '<div style="padding:20px;font-family:monospace;font-size:11px;color:#8b9dc3">Loading...</div>';
    try {
      var r1 = await fetch(API + '/api/agents');
      var ag = await r1.json();
      var agents = ag.agents || [];

      var r2 = await fetch(API + '/api/products/analyze', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({url: window.location.href, page_title: document.title, page_content: (document.body ? document.body.innerText.substring(0, 500) : ''), network_type: 'private'})
      });
      var ctx = await r2.json();

      var r3 = await fetch(API + '/api/scanner/scan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({content: document.title + ' ' + window.location.href})
      });
      var scan = await r3.json();

      var sc = scan.safety_score || 94;
      badge.textContent = sc;
      badge.style.background = sc >= 70 ? '#10b981' : sc >= 50 ? '#f59e0b' : '#ef4444';

      var h = '';
      // Header
      h += '<div style="padding:12px 16px;background:linear-gradient(135deg,rgba(59,130,246,.12),rgba(139,92,246,.12));border-bottom:1px solid #2a3352;display:flex;align-items:center;justify-content:space-between">';
      h += '<div style="display:flex;align-items:center;gap:8px"><div style="width:24px;height:24px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:13px;color:#fff">&#9889;</div>';
      h += '<div style="font-size:12px;font-weight:700"><span style="background:linear-gradient(135deg,#3b82f6,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Command Center</span></div></div>';
      h += '<div style="font-size:22px;font-weight:800;font-family:monospace;color:' + (sc >= 70 ? '#10b981' : sc >= 50 ? '#f59e0b' : '#ef4444') + '">' + sc + '</div></div>';

      // Body
      h += '<div style="padding:12px 16px;overflow-y:auto;max-height:400px">';

      // URL
      h += '<div style="font-size:9px;font-family:monospace;color:#06b6d4;margin-bottom:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">&#127760; ' + window.location.href + '</div>';

      // Security Scan
      h += '<div style="font-size:8px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:600;font-family:monospace;margin-bottom:6px">Security Scan</div>';
      if (sc >= 70) {
        h += '<div style="display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:8px;font-size:11px;font-weight:600;background:rgba(16,185,129,.1);color:#10b981;margin-bottom:10px">&#9989; Safe — Score ' + sc + '/100</div>';
      } else {
        h += '<div style="display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:8px;font-size:11px;font-weight:600;background:rgba(239,68,68,.1);color:#ef4444;margin-bottom:10px">&#9940; Blocked — Score ' + sc + '/100</div>';
      }

      // Life Stage
      var ls = ctx.life_stage || '';
      var lsDesc = ctx.life_stage_description || '';
      if (ls) {
        var icons = {college_student:'&#127891;',young_professional:'&#128188;',new_family:'&#128106;',homeowner:'&#127968;',small_business_owner:'&#127970;'};
        var icon = icons[ls] || '&#128100;';
        h += '<div style="display:inline-flex;padding:6px 12px;border-radius:100px;font-size:10px;font-weight:600;background:rgba(139,92,246,.1);color:#8b5cf6;border:1px solid rgba(139,92,246,.2);margin-bottom:12px">' + icon + ' ' + ls.replace(/_/g,' ').replace(/\\b\\w/g, function(l){return l.toUpperCase()}) + ' — ' + lsDesc + '</div>';
      }

      // Risk factors
      var risks = ctx.risk_factors || [];
      if (risks.length) {
        risks.forEach(function(r) {
          h += '<div style="font-size:9px;padding:6px 10px;border-radius:6px;margin-bottom:3px;background:rgba(245,158,11,.08);color:#f59e0b">' + r + '</div>';
        });
      }

      // Products
      var recs = ctx.recommendations || [];
      if (recs.length) {
        h += '<div style="font-size:8px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:600;font-family:monospace;margin:12px 0 6px">Gen Products for You</div>';
        recs.slice(0, 4).forEach(function(r) {
          var reason = (r.reasons && r.reasons[0]) ? r.reasons[0] : r.description;
          h += '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:rgba(0,0,0,.2);border-radius:8px;margin-bottom:5px">';
          h += '<div style="font-size:18px">' + (r.icon || '&#128230;') + '</div>';
          h += '<div><div style="font-size:11px;font-weight:600;color:#f1f5f9">' + r.name + '</div>';
          h += '<div style="font-size:9px;color:#06b6d4;font-style:italic;margin-top:1px">&#8627; ' + reason + '</div></div></div>';
        });
      }

      // Agents
      h += '<div style="font-size:8px;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:600;font-family:monospace;margin:12px 0 6px">Agents</div>';
      h += '<div style="display:flex;gap:4px;flex-wrap:wrap">';
      agents.forEach(function(a) {
        var col = a.status === 'active' ? '#10b981' : '#64748b';
        h += '<div style="padding:3px 8px;border-radius:100px;font-size:8px;font-weight:600;font-family:monospace;background:rgba(16,185,129,.08);color:' + col + ';border:1px solid ' + col + '33">' + (a.icon || '') + ' ' + a.name.split(' ')[0] + '</div>';
      });
      h += '</div></div>';

      // Footer
      h += '<div style="padding:8px 16px;border-top:1px solid #2a3352;display:flex;justify-content:space-between;align-items:center">';
      h += '<div style="font-size:8px;font-family:monospace"><span style="background:linear-gradient(135deg,#3b82f6,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700">GEN DIGITAL</span> <span style="color:#64748b">&#183; Hackathon 2026</span></div>';
      h += '<a href="' + API + '/dashboard.html" target="_blank" style="padding:4px 10px;border-radius:6px;font-size:9px;font-weight:600;font-family:monospace;border:1px solid #3b82f6;background:rgba(59,130,246,.1);color:#3b82f6;cursor:pointer;text-decoration:none">Full Dashboard &#8594;</a></div>';

      panel.innerHTML = h;
    } catch(e) {
      panel.innerHTML = '<div style="padding:20px;color:#ef4444;font-family:monospace;font-size:11px">Cannot reach Command Center: ' + e.message + '</div>';
    }
  }
})();
